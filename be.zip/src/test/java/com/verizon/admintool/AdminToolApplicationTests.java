package com.verizon.admintool;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AdminToolApplicationTests {

	@Test
	void contextLoads() {
	}

}
