package com.verizon.admintool.model;

public class AdminRequest {
    public String getAllowTraffic() {
        return allowTraffic;
    }

    public void setAllowTraffic(String allowTraffic) {
        this.allowTraffic = allowTraffic;
    }

    public String getRuleEngineUrl() {
        return ruleEngineUrl;
    }

    public void setRuleEngineUrl(String ruleEngineUrl) {
        this.ruleEngineUrl = ruleEngineUrl;
    }

    String allowTraffic;
    String ruleEngineUrl;


}
