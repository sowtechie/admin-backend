package com.verizon.admintool.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.verizon.admintool.model.AdminRequest;
import com.verizon.admintool.model.AdminRule;
import com.verizon.admintool.model.FriendlyURL;
import com.verizon.admintool.model.UrlStatus;
import com.verizon.admintool.service.AdminService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

@RestController
@CrossOrigin
public class ManagerController {
    @Autowired
    private AdminService adminService;

    @GetMapping("/rules")
    public String getRules() {
        return "[\n" +
                "    {\n" +
                "        \"id\": 291,\n" +
                "        \"name\": \"rule_name\",\n" +
                "        \"type\": \"application\",\n" +
                "        \"uri\": \"/formUri/\",\n" +
                "        \"parameterKeys\": [\n" +
                "            \"Hello Hello\"\n" +
                "        ],\n" +
                "        \"parameterDictionary\": {\n" +
                "            \"paramType\": \"header\",\n" +
                "            \"paramName\": \"x-forwarded-for\",\n" +
                "            \"key\": \"IPAddress\"\n" +
                "        }\n" +
                "    },\n" +
                "    {\n" +
                "        \"id\": 9990,\n" +
                "        \"name\": \"rule_namu\",\n" +
                "        \"type\": \"application\",\n" +
                "        \"uri\": \"/formUri/\",\n" +
                "        \"parameterKeys\": [\n" +
                "            \"Hello Hello\",\n" +
                "            \"Hello Hello\",\n" +
                "            \"Hello Hello\",\n" +
                "            \"Hello Hello\"\n" +
                "        ],\n" +
                "        \"parameterDictionary\": {\n" +
                "            \"paramType\": \"header\",\n" +
                "            \"paramName\": \"x-forwarded-for\",\n" +
                "            \"key\": \"IPAddress\"\n" +
                "        }\n" +
                "    }\n" +
                "]";
    }

    @GetMapping("/groupnames")
    public String getGroupNames() {
        return "[\n" +
                "    \"Billing\",\n" +
                "    \"Order\"\n" +
                "]";
    }

    @PostMapping("/friendlyurl")
    public String postFriendlyURL(@RequestBody FriendlyURL friendlyURL) throws Exception{
        return new ObjectMapper().writeValueAsString(friendlyURL);
    }

    @GetMapping("/friendlyurls")
    public String getAllFriendlyURLs() {
        return "[\n" +
                "        \"http://verizonwireless.com\",\n" +
                "        \"http://infosys.com\"\n" +
                "    ]";
    }

    @GetMapping("/getRule")
    public AdminRule getRule(@RequestParam Integer ruleId) {
        return adminService.getRule(ruleId);
    }

    @PostMapping("/publish")
    public String publish(@RequestBody String payload) {
        System.out.println(payload);
        return "Published successfully";
    }

//
//    @DeleteMapping("/deleteRule")
//    public List<AdminRule> deleteRule() {
//        return adminService.getRules();
//    }
}
